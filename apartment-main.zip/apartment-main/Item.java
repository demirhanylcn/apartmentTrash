public class Item {

    private double volume;
    private int ID;
    private static int IDCount = 1;

    private String name;


    Item(double volume, String name) {
        ID = IDCount++;
        this.name = name;
        this.volume = volume;

    }

    public void setWhereItIsStored(ParkingPlace parkingPlace) {
        this.whereItIsStored = parkingPlace;
    }
    public ParkingPlace getWhereItIsStored() {
        return whereItIsStored;
    }
    public double getVolume() {
        return volume;
    }

    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }


    public String toString() {
        return " ID = " + ID + " volume = " + volume + " name = " + name;
    }

}
