import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Room extends Apartment implements Comparable<Room>{

    private int ID;
    private static int IDcount = 1;
    private double volume;
    private double emptySpace;
    private Person roomOwner;
    private boolean isRentable = true;
    private boolean contractValid = true;

    private int daysPassed = 0;
    private TenantLetter tenantLetter;
    private List<Item> items;

    public Room() {
        items = new ArrayList<>();
    }

    public Room(double volume) {
        this();
        ID = IDcount++;
        this.volume = volume;
        emptySpace = volume;
    }

    public Room(Person roomOwner, double volume) {
        this(volume);
        this.roomOwner = roomOwner;
        isRentable = false;
        tenantLetter = new TenantLetter(this);
    }

    @Override
    public String toString() {
        return "[ volume = " + (int) volume + "] [ is it rentable? " + isRentable + " ] [ Owner = " + roomOwner + " ]";
    }

    public int getApartmentID() { return super.getID();}

    public int getDaysPassed() {
        return daysPassed;
    }

    public Person getRoomOwner() {
        return roomOwner;
    }

    public int getID() {
        return ID;
    }

    public TenantLetter getTenantLetter() {
        return tenantLetter;
    }

    public void checkInRoom(Person person) throws ProblematicTenantException {

        if (person.getTenantLetters().size() < 3) {
            if (roomOwner == null && person.sizeOfProperties() <= 5) {
                if (getTenants().isEmpty())
                    setResponsiblePerson(person);
                roomOwner = person;
                getTenants().add(person);
                person.getRentedRooms().add(this);
                isRentable = false;
                contractValid = true;
            } else System.out.println("this room is not empty. please check out the person first.");
        } else throw new ProblematicTenantException(person);


    }

    public void checkOutRoomAdmin(Person person) {
        if (person == getResponsiblePerson()) {
            int userSelection;
            Scanner userInput = new Scanner(System.in);
            System.out.println("Which person do you want to check out?");
            printPeople();
            while (true) {
                try {
                    userSelection = userInput.nextInt() - 1;
                    if (userSelection >= getTenants().size() || userSelection < 0)
                        System.out.println("Invalid selection. Please try again.");
                    else {
                        person.getTenantLetters().remove(tenantLetter);
                        tenantLetter = null;
                        getTenants().get(userSelection).getRentedRooms().remove(this);
                        if (getTenantsParkingPlace(getTenants().get(userSelection)) != null) {
                            getTenantsParkingPlace(getTenants().get(userSelection)).checkOutParkingPlace(getTenants().get(userSelection));
                        }
                        roomOwner = null;
                        getTenants().remove(userSelection);
                        isRentable = true;
                        break;
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter a number.");
                    userInput.next();
                }
            }
            userInput.close();
        } else {
            System.out.println("This tenant cannot perform this action.");
        }
    }

    public void checkOutRoom(Person person) {
        if (isBelongsApartment(person)) {
            person.getRentedRooms().remove(this);
            if (getTenantsParkingPlace(person) != null) getTenantsParkingPlace(person).checkOutParkingPlace(person);
            roomOwner = null;
            isRentable = true;
            getTenants().remove(person);
            person.getTenantLetters().remove(tenantLetter);
            tenantLetter = null;
        } else System.out.println("this person doesnt belong this room.");
    }

    public void kickRoomOwner(Person person) {
        if (isBelongsApartment(person)) {
            person.getRentedRooms().remove(this);
            if (getTenantsParkingPlace(person) != null) getTenantsParkingPlace(person).checkOutParkingPlace(person);
            roomOwner = null;
            isRentable = true;
            getTenants().remove(person);
        } else System.out.println("this person doesnt belong this room.");


    }

    public void renewContract() {

        if (this.getRoomOwner() != null) {
            Scanner userInput = new Scanner(System.in);
            System.out.println("Would you like to renew your contract for room ID = " + this.getID() + "? \n"
                    + "\n[2] DONT DECIDED YET \n[1] YES \n[0] NO\n" + "If total days(" + this.getDaysPassed() + ")exceed 60 days, [Tenant = " + this.getRoomOwner().getName() + "] will be removed from room.\n");
            int userInputInt;
            while (true) {
                userInputInt = userInput.nextInt();
                if (userInputInt > 2 || userInputInt < 0) System.out.println("please make sure you wrote 1 or 0.");
                else break;
            }
            switch (userInputInt) {
                case 0:
                    System.out.println("contract is cancelled.");
                    contractValid = false;
                    checkOutRoom(this.getRoomOwner());
                    break;
                case 1:
                    System.out.println("contract is renewed.");
                    this.daysPassed = 0;

                    break;
                case 2:
                    System.out.println("giving you some time.");


            }
        } else System.out.println("this room doesnt have any tenant.");

    }

    public void skipDay() {
        daysPassed++;
    }

    public void addItemRoom(Item item) throws TooManyThingsException {
        if (this.getEmptySpace() - item.getVolume() < 0) throw new TooManyThingsException();
        else {
            if (items.contains(item)) {
                System.out.println("This item is already in there. You cannot add the same item twice!");
            } else {
                this.decraseEmptySpaceBy(item.getVolume());
                items.add(item);

            }
        }

    }

    public void decraseEmptySpaceBy(double volume) {
        if (this.emptySpace - volume < 0)
            System.out.println("the operation you are trying to do is exceeding the limit of the parking place. ");
        else this.emptySpace -= volume;
    }

    public double getEmptySpace() {
        return emptySpace;
    }

    @Override
    public int compareTo(Room other) {
        return (int)this.getVolume() - (int)other.getVolume();
    }
}
