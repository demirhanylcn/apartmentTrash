import java.util.ArrayList;
import java.util.List;

public class ParkingPlace extends Apartment {
    private double volume;
    private int ID;
    private static int IDcount = 1;
    private double emptySpace;
    private List<Vehicle> vehicles;
    private List<Item> items;
    private Person owner;

    ParkingPlace() {
        vehicles = new ArrayList<>();
        items = new ArrayList<>();
    }

    ParkingPlace(double length, double width, double height) {
        this();
        this.ID = IDcount++;
        volume = calculateVolume(length, width, height);
        emptySpace = volume;
    }


    public String toString() {
        return "volume = " + getVolume() + " ID = " + ID + " emptySpace = " + getEmptySpace();
    }


    public double getVolume() {
        return volume;
    }


    public int getID() {
        return ID;
    }

    public double getEmptySpace() {
        return emptySpace;
    }

    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setOwner(Person owner) {
        this.owner = owner;
    }

    public Person getOwner() {
        return owner;
    }

    public void checkInParkingPlace(Person person) {
        if (owner == null && person.sizeOfProperties() <= 5) {
            owner = person;
            person.getRentedParkingPlaces().add(this);
        } else System.out.println("you can not rent this place. it is already full.");
    }

    public void checkOutParkingPlace(Person person) {
        owner = null;
        for (Vehicle each : vehicles) each.setStored(false);
        vehicles.clear();
        items.clear();
        emptySpace = volume;
        person.getRentedParkingPlaces().remove(this);

    }

    public double calculateVolume(double length, double width, double height) {
        volume = length * width * height;
        return volume;
    }

    public void decraseEmptySpaceBy(double volume) {
        if (this.emptySpace - volume < 0)
            System.out.println("the operation you are trying to do is exceeding the limit of the parking place. ");
        else this.emptySpace -= volume;
    }

    public void addVehicle(Vehicle vehicle) {
        if (vehicles.contains(vehicle)) {
            System.out.println("This vehicle is already in there. You cannot add the same object twice!");
        } else {
            this.decraseEmptySpaceBy(vehicle.getVolume());
            vehicles.add(vehicle);
            vehicle.setStored(true);
            vehicle.setWhereItIsStored(this);

        }
    }

    public void addItemParkingPlace(Item item) {
        if (items.contains(item)) {
            System.out.println("This item is already in there. You cannot add the same item twice!");
        } else {
            this.decraseEmptySpaceBy(item.getVolume());
            items.add(item);

        }
    }
}
