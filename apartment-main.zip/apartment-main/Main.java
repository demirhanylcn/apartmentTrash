import java.io.IOException;

public class Main {
    public static void main(String[] args) throws ProblematicTenantException, IOException {


        checkRentals checkRentals = new checkRentals();
        Thread thread = new Thread(checkRentals);
        thread.start();


    }

}

