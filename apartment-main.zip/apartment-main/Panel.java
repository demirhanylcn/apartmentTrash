import java.io.IOException;

import java.util.List;
import java.util.Scanner;

public class Panel {

    Person currentPerson;
    Apartment currentApartment;
    Item currentItem;
    Vehicle currentVehicle;
    ParkingPlace currentParkingPlace;


    public void startProgram() {

    }

    public Apartment selectApartment() {
        int count = 0;
        List<Apartment> apartmentList = Apartment.getAllApartments();
        for (Apartment each : apartmentList) {
            System.out.println("[" + count++ + "] " + each);
        }
        Scanner userInput = new Scanner(System.in);
        int userInputInt;
        System.out.println("which apartment you want to choose?");

        while (true) {
            userInputInt = userInput.nextInt();
            if (!(userInputInt > apartmentList.size() || userInputInt < 0)) break;
            else System.out.println("please choose apartment in range.");
        }
        return apartmentList.get(userInputInt);


    }

    public Person selectPersonFromApartment(Apartment apartment) {
        int count = 0;
        List<Person> tenants = apartment.getTenants();
        int userInputInt;
        if (tenants.size() == 0) System.out.println("there is no tenant living in here.");
        else {
            for (Person each : tenants) {
                System.out.println("[" + count++ + "] " + each);
            }
            Scanner userInput = new Scanner(System.in);
            System.out.println("which person you want to choose?");

            while (true) {
                userInputInt = userInput.nextInt();
                if (!(userInputInt > tenants.size() - 1 || userInputInt < 0)) break;
                else System.out.println("please choose person in range.");
            }
            return tenants.get(userInputInt);
        }
        return null;
    }

    public Person selectPerson() {

        int count = 0;
        List<Person> people = Person.getAllPeople();
        int userInputInt;
        if (people.size() == 0) System.out.println("there is no one to select.");
        else {
            for (Person each : people) {
                System.out.println("[" + count++ + "] " + each);
            }
            Scanner userInput = new Scanner(System.in);
            System.out.println("which person you want to choose?");

            while (true) {
                userInputInt = userInput.nextInt();
                if (!(userInputInt > people.size() - 1 || userInputInt < 0)) break;
                else System.out.println("please choose person in range.");
            }
            return people.get(userInputInt);
        }
        return null;
    }

    public Apartment createApartment() {
        double userInputs[] = new double[8];
        double userInputDouble;
        int userInputInt;
        Scanner userInput = new Scanner(System.in);


        for (int i = 0; i < userInputs.length; i++) {
            if (i == 0) {
                System.out.println("What will be the length of the room?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            } else if (i == 1) {
                System.out.println("What will be the width of the room?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            } else if (i == 2) {
                System.out.println("What will be the height of the room?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            } else if (i == 3) {
                System.out.println("What will be the length of the parking place?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            } else if (i == 4) {
                System.out.println("What will be the width of the parking place?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            } else if (i == 5) {
                System.out.println("What will be the height of the parking place?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            } else if (i == 6) {
                System.out.println("How many rooms will be there?");
                while (true) {
                    userInputInt = userInput.nextInt();
                    if (userInputInt <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputInt;
                        break;
                    }
                }
            } else {
                System.out.println("How many parking places will be there?");
                while (true) {
                    userInputInt = userInput.nextInt();
                    if (userInputInt < 0) System.out.println("please give number bigger or equal to 0.");
                    else {
                        userInputs[i] = userInputInt;
                        break;
                    }
                }
            }
        }
        return new Apartment(userInputs[0], userInputs[1], userInputs[2], userInputs[3], userInputs[4], userInputs[5], (int) userInputs[6], (int) userInputs[7]);
    }

    public Person createPerson() {
        String userInputs[] = new String[2];
        String userInputString;
        Scanner userInput = new Scanner(System.in);


        for (int i = 0; i < userInputs.length; i++) {
            if (i == 0) {
                System.out.println("What will be the name of the person?");
                while (true) {
                    userInputString = userInput.nextLine();
                    userInputs[i] = userInputString;
                    break;

                }
            } else if (i == 1) {
                System.out.println("What will be the surname of the person?");
                while (true) {
                    userInputString = userInput.nextLine();
                    userInputs[i] = userInputString;
                    break;

                }
            }
        }
        return new Person(userInputs[0], userInputs[1]);
    }

    public ParkingPlace createParkingPlace() {
        double userInputs[] = new double[3];
        double userInputDouble;
        Scanner userInput = new Scanner(System.in);
        for (int i = 0; i < userInputs.length; i++) {
            if (i == 0) {
                System.out.println("What will be the length of the parking place?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            } else if (i == 1) {
                System.out.println("What will be the width of the parking place?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            } else if (i == 2) {
                System.out.println("What will be the height of the parking place?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            }
        }


        return new ParkingPlace(userInputs[0], userInputs[1], userInputs[2]);
    }

    public Vehicle createVehicle() {
        new Vehicle(2, 2, "asd", type.boat);
        double userInputs[] = new double[2];
        type[] types = {type.offRoadCar, type.cityCar, type.boat, type.motorcycle, type.amphibious};
        type givenType = null;
        String model = null;
        double userInputDouble;
        int userInputInt;
        Scanner userInput = new Scanner(System.in);

        for (int i = 0; i < 4; i++) {
            if (i == 0) {
                System.out.println("What will be the volume of the car?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            } else if (i == 1) {
                System.out.println("What will be the torque of the car?");
                while (true) {
                    userInputDouble = userInput.nextDouble();
                    if (userInputDouble <= 0) System.out.println("please give number bigger than 0.");
                    else {
                        userInputs[i] = userInputDouble;
                        break;
                    }
                }
            } else if (i == 2) {
                System.out.println("What will be the model of the car?");
                model = userInput.nextLine();
            } else {
                System.out.println("What will be the type of the car?");
                System.out.println("[0] offRoadCar \n" +
                        "    [1] cityCar\n" +
                        "    [2] boat\n" +
                        "    [3] motorcycle\n" +
                        "    [4] amphibious \n");
                while (true) {
                    userInputInt = userInput.nextInt();
                    if (userInputInt < 0 || userInputInt >= types.length)
                        System.out.println("please give a number in range.");
                    else {
                        givenType = types[userInputInt];
                        break;
                    }
                }
            }
        }


        return new Vehicle(userInputs[0], userInputs[1], model, givenType);
    }

    public Vehicle selectVehicle(Person person) {
        int count = 0;
        int userInputInt;
        Scanner userInput = new Scanner(System.in);
        System.out.println("which car you would like to choose");

        for (Vehicle each : person.getOwnedCars()) {
            System.out.println("[" + count++ + "]" + each);
        }
        while (true) {
            userInputInt = userInput.nextInt();
            if (userInputInt < 0 || userInputInt > count)
                System.out.println("please give number in range.");
            else break;
        }
        return person.getOwnedCars().get(userInputInt);
    }

    public void storeVehicle(Vehicle vehicle, ParkingPlace parkingPlace ) {


    }

    public void getApp() throws IOException {
        Scanner userInput = new Scanner(System.in);
        int userInputInt;
        boolean closePanel = false;

        System.out.println("\nWelcome to estate app. How can I help you today?\n");
        while (!closePanel) {
            System.out.println("[0] Select Apartment || [1] Select Person (Apartment) \t\t\t\t Current Apartment = " + currentApartment + "\n" +
                    "[2] Select Person || [EMPTY]\n" +
                    "[3] Create Apartment || [4] Create Person \t\t\t\t Current Item = " + currentItem + "\n" +
                    "[5] Create Parking Place || [6] Create Car \t\t\t\t Current Person = " + currentPerson + "\n" +
                    "[7] Store Car || [8] Create Item \t\t\t\t\t\t Current Vehicle = " + currentVehicle + "\n" +
                    "[9] Store Item || [10] Run Program\t\t\t\t\t\t Current Parking Place = " + currentParkingPlace + "\n" +
                    "[11] Exit Program.\n" +
                    "Your input -->" + " ");
            while (true) {
                userInputInt = userInput.nextInt();
                if (userInputInt < 0 || userInputInt > 11) System.out.println("please write number in range.");
                else break;
            }
            switch (userInputInt) {
                case 0: {
                    currentApartment = selectApartment();
                    break;
                }
                case 1: {
                    if (currentApartment == null) {
                        System.out.println("please choose apartment first.");
                        currentApartment = selectApartment();
                    } else currentPerson = selectPersonFromApartment(currentApartment);
                    break;
                }
                case 2: {
                    currentPerson = selectPerson();
                    break;
                }
                case 3: {
                    currentApartment = createApartment();
                    break;
                }
                case 4: {
                    currentPerson = createPerson();
                    break;
                }
                case 5: {
                    currentParkingPlace = createParkingPlace();
                    break;
                }
                case 6: {
                    currentVehicle = createVehicle();
                    break;
                }
                case 7: {
                    if (currentApartment == null) {
                        System.out.println("please select apartment first.");
                        selectApartment();
                    } else if (currentVehicle == null) {
                        System.out.println("please select vehicle.");
                        selectVehicle();
                    } else {
                        storeVehicle(currentApartment);
                    }

                    break;
                }
                case 10: {
                    closePanel = true;
                    break;
                }
                case 11: {
                    System.out.println("thank you for choosing us. :>");
                    System.exit(1);
                }
            }
        }


    }


}

